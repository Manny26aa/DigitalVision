const TOKEN_ADMIN = 'Bearer admin-token-secret'; 

// Protección de ruta
if (localStorage.getItem('adminLogueado') !== 'true') {
    window.location.href = 'admin.html';
}

document.addEventListener('DOMContentLoaded', () => {
    cargarConsultas();

    document.getElementById('btn-logout').addEventListener('click', () => {
        localStorage.removeItem('adminLogueado');
        window.location.href = 'admin.html'; 
    });

    const buscador = document.getElementById('buscador');
    const filtroEstado = document.getElementById('filtro-estado');
    
    const aplicarFiltros = () => {
        const texto = buscador.value.toLowerCase();
        const estado = filtroEstado.value;
        const filas = document.querySelectorAll('#tabla-consultas tr');

        filas.forEach(fila => {
            const contenido = fila.textContent.toLowerCase();
            const esLeida = fila.getAttribute('data-leida') === 'true';
            
            let coincideTexto = contenido.includes(texto);
            let coincideEstado = true;
            
            if (estado === 'leidas') coincideEstado = esLeida;
            if (estado === 'no-leidas') coincideEstado = !esLeida;

            fila.style.display = (coincideTexto && coincideEstado) ? '' : 'none';
        });
    };

    buscador.addEventListener('input', aplicarFiltros);
    filtroEstado.addEventListener('change', aplicarFiltros);
});

async function cargarConsultas() {
    try {
        const res = await fetch('/api/consultas', {
            headers: { 'Authorization': TOKEN_ADMIN }
        });
        
        if (res.status === 403) {
            localStorage.removeItem('adminLogueado');
            window.location.href = 'admin.html';
            return;
        }

        const consultas = await res.json();
        const tbody = document.getElementById('tabla-consultas');
        tbody.innerHTML = '';

        consultas.forEach(c => {
            const fecha = new Date(c.fecha).toLocaleDateString('es-AR');
            const estadoClass = c.leida ? 'badge-leida' : 'badge-no-leida';
            const estadoTexto = c.leida ? 'Leída' : 'No Leída';

            tbody.innerHTML += `
                <tr data-leida="${c.leida}">
                    <td>${c.id}</td>
                    <td>${c.nombre}</td>
                    <td>${c.email}</td>
                    <td>${c.asunto}</td>
                    <td>${fecha}</td>
                    <td>
                        <span class="${estadoClass}" onclick="cambiarEstado(${c.id}, ${!c.leida})" style="cursor:pointer;">
                            ${estadoTexto}
                        </span>
                    </td>
                    <td>
                        <button onclick="verDetalle(${c.id})" style="background: var(--azul); color: white; border: none; padding: 5px 10px; border-radius: 3px; cursor: pointer;">Ver</button>
                    </td>
                </tr>
            `;
        });
    } catch (error) {
        console.error('Error al cargar consultas', error);
    }
}

window.cambiarEstado = async (id, nuevoEstado) => {
    try {
        await fetch(`/api/consultas/${id}/leida`, {
            method: 'PUT',
            headers: { 
                'Content-Type': 'application/json',
                'Authorization': TOKEN_ADMIN 
            },
            body: JSON.stringify({ leida: nuevoEstado })
        });
        cargarConsultas(); 
    } catch (error) {
        alert('Error al actualizar estado');
    }
};

window.verDetalle = async (id) => {
    try {
        const res = await fetch(`/api/consultas/${id}`, {
            headers: { 'Authorization': TOKEN_ADMIN }
        });
        const c = await res.json();

        document.getElementById('modal-asunto').innerText = c.asunto;
        document.getElementById('modal-nombre').innerText = c.nombre;
        document.getElementById('modal-email').innerText = c.email;
        document.getElementById('modal-telefono').innerText = c.telefono || 'No especificado';
        document.getElementById('modal-fecha').innerText = new Date(c.fecha).toLocaleString('es-AR');
        document.getElementById('modal-mensaje').innerText = c.mensaje;
        
        document.getElementById('modal-detalle').style.display = 'flex';
    } catch (error) {
        alert('Error al cargar el detalle');
    }
};

window.cerrarModal = () => {
    document.getElementById('modal-detalle').style.display = 'none';
}