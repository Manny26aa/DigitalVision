document.addEventListener('DOMContentLoaded', () => {
    cargarServicios();
    configurarFormulario();
});

async function cargarServicios() {
    try {
        const respuesta = await fetch('/api/servicios');
        const servicios = await respuesta.json();
        const contenedor = document.getElementById('contenedor-servicios');
        
        servicios.forEach(servicio => {
            contenedor.innerHTML += `
                <div class="servicio-card">
                    <div class="servicio-icono">${servicio.icono}</div>
                    <h3>${servicio.titulo}</h3>
                    <p>${servicio.descripcion}</p>
                    <a href="#contacto" class="precio" style="text-decoration: none;">${servicio.precio} &rarr;</a>
                </div>
            `;
        });
    } catch (error) {
        console.error('Error al cargar servicios:', error);
    }
}

function configurarFormulario() {
    const form = document.getElementById('formulario-contacto');
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const datos = {
            nombre: document.getElementById('nombre').value,
            email: document.getElementById('email').value,
            telefono: document.getElementById('telefono').value,
            asunto: document.getElementById('asunto').value,
            mensaje: document.getElementById('mensaje').value
        };

        try {
            const respuesta = await fetch('/api/consultas', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(datos)
            });

            if (respuesta.ok) {
                document.getElementById('mensaje-exito').style.display = 'block';
                document.getElementById('mensaje-exito').innerText = '¡Consulta enviada con éxito! Nos pondremos en contacto pronto.';
                form.reset();
            }
        } catch (error) {
            alert('Error al enviar la consulta. Intente más tarde.');
        }
    });
}