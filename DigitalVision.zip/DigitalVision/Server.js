const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = 3000;


app.use(cors());
app.use(express.json());


app.use(express.static(path.join(__dirname, 'public')));


const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '', 
    database: 'digital_vision_db'
});

db.connect((err) => {
    if (err) {
        console.error('Error conectando a MySQL:', err);
        return;
    }
    console.log('Conectado a la base de datos MySQL (createConnection)');
});


app.get('/api/servicios', (req, res) => {
    db.query('SELECT * FROM servicios', (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});


app.post('/api/consultas', (req, res) => {
    const { nombre, email, telefono, asunto, mensaje } = req.body;
    const query = 'INSERT INTO consultas (nombre, email, telefono, asunto, mensaje) VALUES (?, ?, ?, ?, ?)';
    db.query(query, [nombre, email, telefono, asunto, mensaje], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.status(201).json({ message: 'Consulta guardada con éxito' });
    });
});




app.post('/api/login', (req, res) => {
    const { usuario, password } = req.body;
    const query = 'SELECT * FROM administradores WHERE usuario = ? AND password = ?';
    db.query(query, [usuario, password], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        if (results.length > 0) {
            res.json({ success: true, message: 'Login exitoso' });
        } else {
            res.status(401).json({ success: false, message: 'Credenciales incorrectas' });
        }
    });
});

// GET /api/consultas
app.get('/api/consultas', (req, res) => {
    const authHeader = req.headers.authorization;
    if (authHeader !== 'Bearer admin-token-secret') {
        return res.status(403).json({ error: 'No autorizado' });
    }
    db.query('SELECT * FROM consultas ORDER BY fecha DESC', (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});


app.get('/api/consultas/:id', (req, res) => {
    const authHeader = req.headers.authorization;
    if (authHeader !== 'Bearer admin-token-secret') {
        return res.status(403).json({ error: 'No autorizado' });
    }
    db.query('SELECT * FROM consultas WHERE id = ?', [req.params.id], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        if (results.length === 0) return res.status(404).json({ error: 'No encontrada' });
        res.json(results[0]);
    });
});


app.put('/api/consultas/:id/leida', (req, res) => {
    const authHeader = req.headers.authorization;
    if (authHeader !== 'Bearer admin-token-secret') {
        return res.status(403).json({ error: 'No autorizado' });
    }
    const { leida } = req.body;
    db.query('UPDATE consultas SET leida = ? WHERE id = ?', [leida, req.params.id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Estado actualizado' });
    });
});


app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});